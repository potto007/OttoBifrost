# Changelog

All notable changes to OttoBifrost.

## v1.2.0

- `StaticView` is now the default `PreviewMode`. v1.1.0 wrote `LiveView` into every
  config file the first time it ran, so a saved `LiveView` says nothing about what
  you chose. The first time v1.2.0 loads a config file saved by an older version, it
  switches `LiveView` to `StaticView` and logs the change. After that it leaves the
  setting alone.
- `StaticView` pictures shimmer and ripple, fade out toward the rim, and let 30% of
  the portal behind them show through.
- `StaticView` no longer takes a picture mid-teleport, when the far side is the area
  you are leaving.
- Fast teleports keep their own clock. In debug mode, Server devcommands' "Debug mode
  fast teleport" sets the teleport timer to 15. The fast path read that as past its
  8 second limit and handed the trip to vanilla on the first frame, so you could land
  before the floors arrived.
- Standing near built destinations costs less. The pass that creates their objects
  ran every 0.2 s even when nothing was left to create. Now each empty pass doubles
  the wait, up to 2 s, and any change to those zones or their objects brings it back
  to 0.2 s.
- With `LogPerformance` on, the log records "server reports complete" once per
  change. The server repeats every state whenever your list of nearby portals
  changes, and each repeat used to get its own line.

## v1.1.0

- New `PreviewMode` setting in the `Preview` section. Not synced.
- `LiveView`, the default, keeps the continuous, head-tracking preview from v1.0.0.
- `StaticView` takes one picture of the destination once the objects around the
  arrival point are built, and renders nothing after that. Each approach takes a
  new picture.

## v1.0.0

- First release, for Valheim 1.0.12 and BepInEx 5.4.2350.
- Live preview of the far end on wood and stone portals, from your eye position,
  on both sides of the portal.
- The destination starts to load within 15 m of a portal, and the loaded area grows
  as you get closer.
- The nearest portal loads first and at full size. Other destinations load 3x3,
  enough for their previews. The nearest only changes when another portal is 2 m
  closer.
- Zones load ring by ring across all destinations and stay loaded while you stand
  near them. Objects come up in vanilla type order, terrain edits first, so nothing
  appears before the ground under it.
- Faster teleports to a preloaded destination. The trip ends once every object
  around the arrival point exists and there is a floor under you, and vanilla takes
  over at the 8 second mark. Dungeon doors keep vanilla behaviour.
- With the mod on a dedicated server, the server also sends the objects around each
  destination you stand near and reports when one is complete. At most 8 per player,
  and only for portals within 30 m of that player.
- Only the nearest preview renders live, at a rate that drops with distance, without
  shadows and with a 300 m draw distance.
- `LogPerformance` writes a timing summary every 5 seconds. Off by default.
